CADENA_FIN = "fin"
menor = 0
mayor = 0
numero = 0
cadena = ""
contador = 0


while cadena != CADENA_FIN:
    try:
        print("Introduzca un número o la cadena",
         CADENA_FIN, "para salir\n")
        cadena = input()
        if cadena == CADENA_FIN:
            break        
        numero = float(cadena)
        contador = contador + 1
        if contador == 1:
            menor = numero
            mayor = numero
        else:
            if numero < menor:
                menor = numero
            if numero > mayor:
                mayor = numero       
    except:
        print("Error. Introduzca solo números")

print("Mínimo", menor)
print("Máximo:", mayor)

