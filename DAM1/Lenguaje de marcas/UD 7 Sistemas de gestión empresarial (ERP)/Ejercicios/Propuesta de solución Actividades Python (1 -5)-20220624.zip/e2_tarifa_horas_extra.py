TOPE_SEMANAL = 40
INCREMENTO_HORA_EXTRA = 1.5
# https://docs.python.org/es/3/library/constants.html?highlight=none#None
# None es un valor constante especial que se puede almacenar en una variable para indicar que la variable está “vacía”.
horas = None
tarifa = None
pago = None
try: 
    while horas == None or horas<0:
        horas = float(input("Introduzca las horas trabajadas esta semana. Solo se aceptan números positivos o cero\n"))
    while tarifa == None or tarifa<0:
        tarifa = float(input("Introduzca la tarifa por hora trabajada. Solo se aceptan números positivos o cero\n"))
    if horas > 40:
        horas_extra = horas - TOPE_SEMANAL
        pago_extra = horas_extra * tarifa * INCREMENTO_HORA_EXTRA
        pago = TOPE_SEMANAL * tarifa + pago_extra
    elif horas >=0:
        pago = horas * tarifa    
    print("El pago correspondiente a esta semana es: ", pago, "€")
except: 
    print("Error, introduzca números positivos o cero")
