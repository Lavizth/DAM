CADENA_FIN = "fin"
menor = 0
mayor = 0
numero = 0
cadena = ""
contador = 0
lista = []


while cadena != CADENA_FIN:
    try:
        print("Introduzca un número o la cadena",
         CADENA_FIN, "para salir\n")
        cadena = input()
        if cadena == CADENA_FIN:
            break        
        numero = float(cadena)
        lista.append(numero)       
    except:
        print("Error. Introduzca solo números")
if len(lista) != 0:
    print("Mínimo", min(lista))
    print("Máximo:", max(lista))

