CONSTANTE = 1.8
INCREMENTO = 32
try:
    celsius = float(input("Introduzca el número de grados Celsius\n"))
    fahrenheit = celsius*CONSTANTE + INCREMENTO
    print("La equivalencia de", celsius, "grados Celsius en grados Fahrenheith es:", fahrenheit)
except:
    print("No ha podido realizarse la operación.")
    print("Recuerde, solo se aceptan números")

