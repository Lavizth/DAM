CADENA_FIN = "fin"
contador = 0
sumatorio = 0
cadena = ""


while cadena != CADENA_FIN:
    try:
        print("Introduzca un número o la cadena",
         CADENA_FIN, "para salir\n")
        cadena = input()
        if cadena == CADENA_FIN:
            break        
        sumatorio = sumatorio + float(cadena)
        contador = contador + 1
       
    except:
        print("Error. Introduzca solo números")

print("Números introducidos:", contador)
print("Sumatorio:", sumatorio)
if contador != 0:
    print("Media:", sumatorio/contador)
else:
     print("Media: 0")
