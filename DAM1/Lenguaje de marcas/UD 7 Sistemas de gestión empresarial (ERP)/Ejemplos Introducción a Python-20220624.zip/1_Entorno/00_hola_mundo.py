print("¡Hola Mundo!")
print