# https://docs.python.org/es/3/library/functions.html?highlight=len#len
lista_numeros = [1, 20, 300, 4]
lista_cadenas = ["a", "beta", [2, 1]]
vacia = []

print("len(lista_numeros): ", len(lista_numeros))
print("len(lista_cadenas): ", len(lista_cadenas))
print("len(vacia): ", len(vacia))
