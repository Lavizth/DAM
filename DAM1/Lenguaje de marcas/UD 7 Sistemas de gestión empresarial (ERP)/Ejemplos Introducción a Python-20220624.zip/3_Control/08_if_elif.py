numero= int(input("Introduzca un número entero\n"))
if numero == 0:
    print("Ha introducido un cero")   
elif numero > 0:
     print(numero, "es un número positivo y distinto de cero")  
else:
   print(numero, "es un número negativo y distinto de cero")
print("Fin")