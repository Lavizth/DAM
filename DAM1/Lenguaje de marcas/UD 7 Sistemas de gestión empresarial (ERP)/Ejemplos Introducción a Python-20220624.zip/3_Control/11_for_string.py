palabra = input("Introduzca una palabra para su deletreo\n")
for c in palabra:
    print(c)