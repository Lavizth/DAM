numero= int(input("Introduzca un número entero distinto de cero\n"))
if numero == 0:
    print("El cero no está permitido")
else :
   print("Ha introducido el número", numero)
print("Fin") # Esta línea no está indentad y  se ejecuta siempre, no depende de las condiciones