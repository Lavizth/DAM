numero = int(input("Introduce un número entero positivo \n"))
while numero > 0: 
    print("Cuenta atrás", numero)
    numero = numero -1
print("Fin", numero)
    