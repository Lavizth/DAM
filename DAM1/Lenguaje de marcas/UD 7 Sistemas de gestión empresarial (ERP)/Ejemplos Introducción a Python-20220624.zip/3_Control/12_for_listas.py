lista = [1, 1, 2, 3, 5, 8, 13]
for i in lista:
    print(i)