numero= int(input("Introduzca un número entero\n"))
if numero > 0:
    print(numero, "es un número positivo")
print("Fin") # Esta línea no está indentada y  se ejecuta siempre, no depende de la condición. 