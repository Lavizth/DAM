# Por defecto, input devuelve un string. Habrá que convertir a int() o a float() dependiendo del tipo de dato esperado para poder operar como cantidades
# Funciones de conversión de tipos: str(), float(), int()
lado = float(input("Indique el número de cm del lado del cuadrado: "))
print("El área del cuadrado es:", lado ** 2) 


