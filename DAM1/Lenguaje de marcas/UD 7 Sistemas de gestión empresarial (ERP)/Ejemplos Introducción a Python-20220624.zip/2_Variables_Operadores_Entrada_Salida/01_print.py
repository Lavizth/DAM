# Esto es un comentario
# https://docs.python.org/es/3/library/functions.html#print
print("Se puede", "usar varias cadenas en la función print().", "Se separarán por defecto con espacios.", "Se añadirá por defecto un retorno de carro.")

# Se pueden usar comillas dobles o simples para las cadenas de texto, pero se recomienda ser consistente
# No se usan puntos y coma al final de las instrucciones

print("Se puede usar", "otro separador", sep='-', end="\n\n@") #Esto es un comentario
    






