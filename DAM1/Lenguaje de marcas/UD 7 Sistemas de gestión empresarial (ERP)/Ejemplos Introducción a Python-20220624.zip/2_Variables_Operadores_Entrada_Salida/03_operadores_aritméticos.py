# Operadoes aritméticos: 
# suma:  0 + 32
# resta: hour - 1
# multiplicación: hour * 60
# división: minutes / 60
# división entera (cociente): //
# exponente: 5**2
# resto división entera: 5 % 2

print("0 + 32=", 0 + 32)

hour = 60
print("hour - 1=", hour - 1)

print("hour * 60=", hour * 60)

minutes = 121
print("minutes / 60=", minutes / 60)

print("minutes // 60=", minutes // 60)

print("5 ** 2=", 5 ** 2 )

print("5 % 2=", 5 % 2 )
