/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 2
ProductModelID as '@modelID',
Name as nombreModelo,
CatalogDescription as documento
  FROM [AdventureWorksLT2016].[SalesLT].[ProductModel]
  WHERE CatalogDescription IS NOT NULL
  ORDER BY ProductModelID
  FOR XML PATH('modelo'), root('modelos')
  
  
  -- Ejercicio 3
  -- '../..' 
  -- Desde cuenta ahorro hay que subir dos niveles para situarse en <doc_cliente>
  