DECLARE @lineas_pedido xml
SELECT @lineas_pedido = aliasColumna
--completa con la ruta a tu archivo lineas_pedido.xml
FROM OPENROWSET (BULK '               ', SINGLE_BLOB)
AS aliasTabla (aliasColumna)


SELECT @lineas_pedido

DECLARE @hdoc int
EXEC sp_xml_preparedocument @hdoc OUTPUT, @lineas_pedido



INSERT INTO SalesLT.SalesOrderDetail(SalesOrderID,  OrderQty, ProductID, UnitPrice)
-- completa el select
SELECT 












EXEC sp_xml_removedocument @hdoc