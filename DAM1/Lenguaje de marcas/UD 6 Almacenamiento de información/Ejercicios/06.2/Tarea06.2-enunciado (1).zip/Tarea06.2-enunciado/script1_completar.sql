/****** Script for SelectTopNRows command from SSMS  ******/
SELECT 


    
  FROM [AdventureWorksLT2016].[SalesLT].[SalesOrderHeader]
  ORDER BY SalesOrderID

  