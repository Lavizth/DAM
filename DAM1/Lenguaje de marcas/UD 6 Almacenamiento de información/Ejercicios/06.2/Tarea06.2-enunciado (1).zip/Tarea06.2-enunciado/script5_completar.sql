DECLARE @municipios xml
SELECT @municipios = aliasColumna
-- a�ade la ruta al archivo municipios-schema.xml que corresponda en tu caso
FROM OPENROWSET (BULK '', SINGLE_BLOB)
AS aliasTabla (aliasColumna)


SELECT @municipios

DECLARE @hdoc int
EXEC sp_xml_preparedocument @hdoc OUTPUT, @municipios


INSERT INTO dbo.Municipio(DocMunicipio)

--completa el select
SELECT 







EXEC sp_xml_removedocument @hdoc

