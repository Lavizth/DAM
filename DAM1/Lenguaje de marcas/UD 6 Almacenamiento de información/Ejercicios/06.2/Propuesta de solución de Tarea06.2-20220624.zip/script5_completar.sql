DECLARE @municipios xml
SELECT @municipios = aliasColumna
FROM OPENROWSET (BULK 'C:\Users\wadmin\Desktop\Tarea06.2_new\municipios-schema.xml', SINGLE_BLOB)
AS aliasTabla (aliasColumna)


SELECT @municipios

DECLARE @hdoc int
EXEC sp_xml_preparedocument @hdoc OUTPUT, @municipios


INSERT INTO dbo.Municipio(DocMunicipio)
SELECT doc
FROM OPENXML (@hdoc, '/' , 2)
WITH(
  	doc XML '.'
	
)

EXEC sp_xml_removedocument @hdoc