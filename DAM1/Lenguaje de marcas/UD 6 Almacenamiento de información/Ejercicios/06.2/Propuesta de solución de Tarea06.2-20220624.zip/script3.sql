CREATE XML SCHEMA COLLECTION MunicipioSchemaCollection AS
N'<?xml version="1.0" encoding="UTF-16"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
    <xs:element name="municipios" type="tipo_municipios"></xs:element>

    <xs:simpleType name="tipo_2decimales">
        <xs:restriction base="xs:decimal">
            <xs:fractionDigits value="2"></xs:fractionDigits>
        </xs:restriction>
    </xs:simpleType>

    <xs:simpleType name="tipo_comunidad">
        <xs:restriction base="xs:string">
            <!-- <xs:pattern value="Galicia|Asturias|Cantabria"></xs:pattern> -->
            <xs:enumeration value="Galicia"></xs:enumeration>
            <xs:enumeration value="Asturias"></xs:enumeration>
            <xs:enumeration value="Cantabria"></xs:enumeration>
        </xs:restriction>
    </xs:simpleType>


    <xs:complexType name="tipo_url">
        <xs:attribute name="href" use="required" type="xs:anyURI" fixed="http://www.turismo.com/municipio" />
    </xs:complexType>


    <xs:complexType name="tipo_festividad">
        <xs:sequence>
            <xs:element name="url" type="tipo_url"></xs:element>
        </xs:sequence>
        <xs:attribute name="valor" use="required" type="xs:gMonthDay" />
    </xs:complexType>


    <xs:complexType name="tipo_hermanado">
        <xs:attribute name="mun_ids" use="required" type="xs:IDREFS" />
    </xs:complexType>

    <xs:complexType name="tipo_municipio">
        <xs:sequence>
            <xs:element name="nombre" type="xs:string" />
            <xs:element name="habitantes" type="xs:positiveInteger" />
            <xs:element name="km" type="tipo_2decimales" />
            <xs:element name="festividad" type="tipo_festividad"></xs:element>
            <xs:element name="hermanado" minOccurs="0" type="tipo_hermanado"></xs:element>
            <xs:element name="comunidad" type="tipo_comunidad" />
        </xs:sequence>
        <xs:attribute name="id" type="xs:ID" use="required" />
        <xs:attribute name="costero" type="xs:boolean" default="true" />
    </xs:complexType>

    <xs:complexType name="tipo_municipios">
        <xs:sequence>
            <xs:element name="municipio" maxOccurs="unbounded"
             minOccurs="0" type="tipo_municipio"></xs:element>
        </xs:sequence>
    </xs:complexType>
</xs:schema>'