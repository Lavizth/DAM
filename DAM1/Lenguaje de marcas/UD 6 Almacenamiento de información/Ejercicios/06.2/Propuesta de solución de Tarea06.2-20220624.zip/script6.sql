DECLARE @lineas_pedido xml
SELECT @lineas_pedido = aliasColumna
FROM OPENROWSET (BULK 'C:\Users\wadmin\Desktop\Tarea06.2_new\lineas_pedido.xml', SINGLE_BLOB)
AS aliasTabla (aliasColumna)


SELECT @lineas_pedido

DECLARE @hdoc int
EXEC sp_xml_preparedocument @hdoc OUTPUT, @lineas_pedido
SELECT *
FROM OPENXML (@hdoc, '/pedido/lineaPedido' , 2)
WITH(
  	SalesOrderID int '../@pedidoID',
	SalesOrderDetailID int '@lineaPedidoID'  ,   	
	OrderQty smallint './cantidad', 
	ProductID int 'productoID',
	UnitPrice money 'precioUnidad'

	
)

EXEC sp_xml_removedocument @hdoc