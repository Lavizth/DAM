/****** Script for SelectTopNRows command from SSMS  ******/
SELECT 

[SalesOrderID]   as '@pedidoID'   
      ,[OrderDate]   as fecha   
      ,[CustomerID]  as clienteID
      ,[TotalDue]  as total
    
  FROM [AdventureWorksLT2016].[SalesLT].[SalesOrderHeader]
  ORDER BY SalesOrderID
  FOR XML PATH('Cabecera_Pedido'), root('Pedidos')
  