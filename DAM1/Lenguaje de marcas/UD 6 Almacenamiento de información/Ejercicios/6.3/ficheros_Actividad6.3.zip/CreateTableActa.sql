USE [AdventureWorksLT2016]
GO

/****** Object:  Table [dbo].[Acta]    Script Date: 23/04/2021 12:11:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Acta](
	[ActaID] [int] IDENTITY(1,1) NOT NULL,
	[CursoActa] [varchar](9) NOT NULL,
	[CicloActa] [varchar](35) NOT NULL,
	[EvalActa] [varchar](10) NOT NULL,
	[DocActa] [xml](CONTENT [dbo].[ActaSchemaCollection]) NULL,
	[FechaActa] [datetime] NOT NULL,
 CONSTRAINT [PK_Acta_ActaID] PRIMARY KEY CLUSTERED 
(
	[ActaID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


