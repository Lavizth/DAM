DECLARE @addresses xml
SELECT @addresses = aliasColumna
FROM OPENROWSET (BULK 'C:\Users\mfernandez\Desktop\A6_3\4_acta_xsd.xml', SINGLE_BLOB)
AS aliasTabla (aliasColumna)
SELECT @addresses

DECLARE @hdoc int
EXEC sp_xml_preparedocument @hdoc OUTPUT, @addresses

INSERT INTO [dbo].[Acta] (CursoActa, CicloActa, EvalActa, DocActa, FechaActa)
SELECT curso, ciclo, eval, doc, fecha
FROM OPENXML (@hdoc, '/acta' , 2)

WITH(
   curso varchar(9) './curso',
   ciclo varchar(35) './@ciclo',
   eval varchar(10) './@eval',
   doc XML '../.',
   fecha datetime './fecha'
    )
    
EXEC sp_xml_removedocument @hdoc
