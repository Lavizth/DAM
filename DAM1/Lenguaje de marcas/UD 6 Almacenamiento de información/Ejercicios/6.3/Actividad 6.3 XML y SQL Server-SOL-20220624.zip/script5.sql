DECLARE @addresses xml
SELECT @addresses = aliasColumna
FROM OPENROWSET (BULK 'C:\Users\mfernandez\Desktop\A6_3\categorias.xml', SINGLE_BLOB)
AS aliasTabla (aliasColumna)
SELECT @addresses

DECLARE @hdoc int
EXEC sp_xml_preparedocument @hdoc OUTPUT, @addresses

INSERT INTO [SalesLT].[ProductCategory] (ParentProductCategoryID, Name)
SELECT A, B
FROM OPENXML (@hdoc, '//Category' , 2)

WITH(
   A int './ParentProductCategoryID',
   B nvarchar(50) 'Name'
    )
    
EXEC sp_xml_removedocument @hdoc
