/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ej5_T4;

/**
 *
 * @author nccasares
 */
public class Pez implements Cloneable {

    protected String nombre;
    private static int numpeces = 0;

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String s) {
        this.nombre = s;
    }

    public Object clone() {
        Object objeto = null;
        try {
            objeto = super.clone();
        } catch (CloneNotSupportedException ex) {
            System.out.println("Error al duplicar");
        }
        return objeto;
    }

    public boolean equals(Pez ese) {
        if (ese.getNombre() == this.getNombre()) {
            return true;
        }
        return false;
        /*boolean res = true;
        if (ese.getNombre() != this.getNombre()) {
            res = false;
        }
        if (ese.getTamanho() != this.getTamanho()) {
            res = false;
        }
        return res;
         */
    }

    ////////
    public int getpeces() {
        return this.numpeces;
    }

    Pez() {
        numpeces++;
    }

    public static void main(String[] args) {
        Pez p1 = new Pez();
        p1.setNombre("Gulli");
        Pez p2 = new Pez();
        p2.setNombre("Escalar");
        Pez p3 = (Pez) p2.clone();
        System.out.println(p1.getNombre());
        System.out.println(p2.getNombre());
        System.out.println(p3.getNombre());
        System.out.println(p3.equals(p2));
        ////
        System.out.println(p3.getpeces());
    }

}
