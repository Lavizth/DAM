/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjerciciosT5Sintesis;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class E4_Calculadora {

    public static int suma(int num1, int num2) {
        return num1 + num2;
    }

    public static int resta(int num1, int num2) {
        return num1 - num2;
    }
    
    public static int multiplicacion(int num1, int num2) {
        return num1 * num2;
    }
    
    public static int division(int num1, int num2) {
        if (num2 == 0) return 0;
        return num1 / num2;
    }
    
    public static double potencia(int num1, int num2) {
        return Math.pow(num1, num2);
    }
    
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        double resultado = 0;
        System.out.println("Introduzca el primer número:");
        int n1 = sc.nextInt();

        System.out.println("Introduzca el segundo número:");
        int n2 = sc.nextInt();

        System.out.println("Introduzca la operación a realizar:");
        String op = sc.next();
        
        switch(op.toLowerCase()) {
            case "suma":
                resultado = suma(n1, n2);
                break;
            case "resta":
                resultado = resta(n1, n2);
                break;
            case "division":
                resultado = division(n1, n2);
                break;
            case "multiplicacion":
                resultado = multiplicacion(n1, n2);
                break;
            case "potencia":
                resultado = potencia(n1, n2);
                break;
        }
        
        System.out.println("El resultado de la operación es: " + resultado);
    }
}
