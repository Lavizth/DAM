/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class A08_Menor100 {

    public static void numMenor100DoWhile() {
        Scanner sc = new Scanner(System.in);
        int num;
        do {
            System.out.println("Introduzca un número menor que 100:");
            num = sc.nextInt();
        } while (num >= 100);
    }

    public static void main(String args[]) {
        numMenor100DoWhile();
    }
}
