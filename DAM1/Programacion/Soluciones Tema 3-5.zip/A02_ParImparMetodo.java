/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class A02_ParImparMetodo {
    public static String esParImpar (int num) {
        String resultado;
        if (num % 2 == 0) 
            resultado = "par";
        else
            resultado = "impar";
        
        return resultado;
    }
    
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el número:");
        int num = sc.nextInt();
        System.out.println("El número introducido es "+ esParImpar(num));
    }
}
