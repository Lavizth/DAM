/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class A14_Cubo {

    public static void obtenerCubo() {
        Scanner sc = new Scanner(System.in);
        int num;
        for (int i = 0; i <= 10; i++) {

            System.out.println("Introduzca el número:");
            num = sc.nextInt();
            System.out.println("Cubo: " + Math.pow(num,3));
        }
    }

    public static void main(String args[]) {
       obtenerCubo();
    }
}
