/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjerciciosT5Sintesis;

import app2.*;
import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class E5_Piramide {

    public static void mostrarPiramide(int filas) {

        for(int altura = 1; altura<=filas; altura++){
            //Espacios en blanco
            for(int blancos = 1; blancos<=filas-altura; blancos++){
                System.out.print(" ");
            }
 
            //Asteriscos
            for(int asteriscos=1; asteriscos<=(altura*2)-1; asteriscos++){
                System.out.print("*");
            }
            System.out.println();
        }
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el número de filas:");
        int num = sc.nextInt();
        mostrarPiramide(num);
    }
}
