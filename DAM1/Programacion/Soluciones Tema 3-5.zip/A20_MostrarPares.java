/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class A20_MostrarPares {

    public static void mostrarPares(int inf, int sup) {      
        for (int i = inf; i <= sup; i++) {
            if (i % 2 == 0) 
                System.out.println("Número par: " + i);
        }
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el límite inferior: ");
        int inf = sc.nextInt();        
        System.out.println("Ingrese el límite superior: ");
        int sup = sc.nextInt();
        
        mostrarPares(inf, sup);
    }
}
