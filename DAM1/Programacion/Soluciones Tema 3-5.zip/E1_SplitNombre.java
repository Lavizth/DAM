/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjerciciosT5Sintesis;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class E1_SplitNombre {    
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca sus apellidos y nombre (apellido1-apellido2-nombre):");
        String datos = sc.next();
        String[] datosSplit = datos.split("-");
        System.out.println(datosSplit[2]+"-"+datosSplit[0]+"-"+datosSplit[1]);
    }
}
