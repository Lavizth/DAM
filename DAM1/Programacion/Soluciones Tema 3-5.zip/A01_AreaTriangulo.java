/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;


/**
 *
 * @author nccasares
 */
public class A01_AreaTriangulo {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Introduzca la base del triángulo:");
        int b = sc.nextInt();
        
        System.out.println("Introduzca la altura del triángulo:");
        int a = sc.nextInt();
        
        float area = b*a/2;
        
        System.out.println("El área es: " + area);
    }
}
