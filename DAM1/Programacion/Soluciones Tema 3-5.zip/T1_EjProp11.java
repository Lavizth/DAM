/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosRaMa;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class T1_EjProp11 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el tiempo:");
        int t = sc.nextInt();
        
        int horas, minutos, segundos;
        System.out.println(t);
        
        horas = t / 3600;
        int restohoras = t % 3600;
        minutos = restohoras / 60;
        segundos = restohoras % 60;
        System.out.println("Horas:" + horas + " Minutos:" + minutos + " Segundos:" + segundos);
        System.out.println(horas * 3600 + minutos * 60 + segundos);
    }
}
