/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class A09_ContarPositivos {

    public static void contarPositivosFor() {
        Scanner sc = new Scanner(System.in);
        int total = 0;
        int num;
        for (int i = 0; i <= 10; i++) {
            System.out.println("Introduzca número:");
            num = sc.nextInt();
            if (num>0)
                total += 1;
        }
        System.out.println("Se han introducido " + total + " números positivos.");
    }

    public static void main(String args[]) {
        contarPositivosFor();
    }
}
