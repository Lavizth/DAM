/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class A13_MediaNotas {

    public static void obtenerMediaNotas() {
        Scanner sc = new Scanner(System.in);
        int sumaNotas = 0;
        int nota;
        for (int i = 1; i <= 7; i++) {
            System.out.println("Introduzca nota:");
            nota = sc.nextInt();
            sumaNotas += nota;
        }
        System.out.println("La nota media de la asignatura es: " + sumaNotas/7);
    }

    public static void main(String args[]) {
        obtenerMediaNotas();
    }
}
