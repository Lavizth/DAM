/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejerciciosRaMa;

/**
 *
 * @author nccasares
 */
public class T1_EjProp8 {

    public static void main(String[] args) {
        char car;
        boolean consonante;
        for (int i = 0; i < 100; i++) {
            consonante = true;
            car = (char) (Math.random() * 26 + 'A');
            switch (car) {
                case 'A':
                    consonante = false;
                    break;
                case 'E':
                    consonante = false;
                    break;
                case 'I':
                    consonante = false;
                    break;
                case 'O':
                    consonante = false;
                    break;
                case 'U':
                    consonante = false;
                    break;
            }
            System.out.print("Generado: " + car + " -> ");
            if (consonante) {
                System.out.println("consonante");
            } else {
                System.out.println("vocal");
            }
        }
    }
}
