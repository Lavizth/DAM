/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjerciciosT5Sintesis;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class E3_Bisiesto {
    public static String esBisiesto (int anho) {
        String resultado;
        if ((anho % 4 == 0) && ((anho % 100 != 0) || (anho % 400 == 0))) 
            resultado = "bisiesto";
        else
            resultado = "no bisiesto";
        
        return resultado;
    }
    
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el año:");
        int a = sc.nextInt();
        System.out.println("El año introducido es "+ esBisiesto(a));
    }
}
