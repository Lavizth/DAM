/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class A03_DivisionMayorMenor {

    public static int dividirMayorMenor(int num1, int num2) {
        int res;
        if (num2 > num1) {
            res = num2 / num1;
        } else {
            res = num1 / num2;
        }
        return res;
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca el primer número:");
        int n1 = sc.nextInt();

        System.out.println("Introduzca el segundo número:");
        int n2 = sc.nextInt();

        System.out.println("La división es: " + dividirMayorMenor(n1, n2));
    }
}
