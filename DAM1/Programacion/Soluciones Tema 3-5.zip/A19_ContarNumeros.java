/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app2;

import java.util.Scanner;

/**
 *
 * @author nccasares
 */
public class A19_ContarNumeros {

    public static void contarNumeros(int n) {
        Scanner sc = new Scanner(System.in);
        int positivos = 0;
        int negativos = 0;
        int ceros = 0;
        int num;
        
        for (int i = 1; i <= n; i++) {
            System.out.println("Introduzca el número: ");
            num = sc.nextInt();
            if (num > 0) 
                positivos++;
            else if (num < 0)
                negativos++;
            else
                ceros++;
        }
        
        System.out.println("Se han introducido " + positivos + " números positivos.");
        System.out.println("Se han introducido " + negativos + " números negativos.");
        System.out.println("Se han introducido " + ceros + " ceros.");
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese la cantidad de números a introducir: ");
        int num = sc.nextInt();
        contarNumeros(num);
    }
}
