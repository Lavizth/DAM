/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjerciciosT5Sintesis;

import app2.*;
import java.io.IOException;

/**
 *
 * @author nccasares
 */
public class E7_FragmentoCodigo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        System.out.println("Introduzca un texto: ");
        while(true){
            int letra = System.in.read();
            System.out.println("ESCRITO: " + (char)letra);
        }
    }
    
}
