/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ficheros;

import java.io.File;

/**
 *
 * @author nccasares
 */
public class act1_1 {

    public static void main(String[] args) {
        listarDirectorioActual();
        listarFicherosRuta(args[0]);
    }

    public static void listarDirectorioActual() {
        String dir = ".";
        File f = new File(dir);
        File[] archivos = f.listFiles();
        System.out.println("Ficheros en el directorio actual: " + archivos.length);
        for (int i = 0; i < archivos.length; i++) {
            System.out.println(archivos[i].getName());
        }
    }

    public static void listarFicherosRuta(String ruta) {
        File f = new File(ruta);
        if (f.exists()) {
            File[] archivos = f.listFiles();
            System.out.println("Ficheros en el directorio actual: " + archivos.length);
            for (int i = 0; i < archivos.length; i++) {
                System.out.println(archivos[i].getName());
            }
        } else {
            System.out.println("La ruta introducida no existe");
        }
    }
}
