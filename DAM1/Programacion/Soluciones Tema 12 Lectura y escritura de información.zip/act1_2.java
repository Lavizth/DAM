package ficheros;


import java.io.*;

public class act1_2 {

    public static void main(String[] args) throws IOException {
        File fichero = new File("Fichero1.txt");
        //File fichero = new File(args[0]);
        FileReader fic = new FileReader(fichero);  

        int i;
        while ((i = fic.read()) != -1)
        {
            System.out.print((char) i);
        }
        System.out.println("");
        fic.close(); 
    }
}
