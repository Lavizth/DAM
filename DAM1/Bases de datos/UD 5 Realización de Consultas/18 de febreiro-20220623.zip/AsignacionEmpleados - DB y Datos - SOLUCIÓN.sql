#-------------------------------------------------------------------------------------------------------------
# La empresa constructora Teis Constructor desea ejecutar un proyecto de realización de un consorcio de
# hoteles, por lo que necesita de varios trabajadores.
# El control del personal se realiza a través de las siguientes tablas:
#
#		Empleado						asignación						hotel
#
#	codEmp 		INT					emp		INT(11)				cdHotel		INT(11)
#	nombre		VARCHAR(60)			hot		INT(11)				nombre		VARCHA(30)
#	pagoXhora	DECIMAL(18,2)		fIni	DATETIME			direccion	VARCHAR(60)
#	profesion	VARCHAR(60)			dias	INT(11)				tipo		VARCHAR(60)
#	supervisor	INT(11)											nivel		INT(11)
#																categoria	INT(11)
#
#	codEmp -> CLAVE PRIMARIA		emp -> CLAVE PRIMARIA		cdHotel -> CLAVE PRIMARIA
#									hot -> CLAVE PRIMARIA
#									fIni-> CLAVE PRIMARIA
#-------------------------------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------------------------------------
#	CREACIÓN DE LA BASE DE DATOS
#-------------------------------------------------------------------------------------------------------------
	DROP 	DATABASE IF EXISTS	AsignacionEmpleados;
    CREATE	DATABASE 			AsignacionEmpleados;
    USE							AsignacionEmpleados;
#-------------------------------------------------------------------------------------------------------------
#	CREACIÓN DE LAS TABLAS
#-------------------------------------------------------------------------------------------------------------
	CREATE TABLE Empleado (
		codEmp 			INT,
        nombre 			VARCHAR( 60 ),
        pagoXhora		DECIMAL( 18, 2 ),
        profesion 		VARCHAR( 60 ),
        supervisor 		INT
        );
        
	CREATE TABLE Hotel (
		cdHotel 		INT,
        nombre			VARCHAR( 30 ),
        direccion 		VARCHAR( 60 ),
        tipo 			VARCHAR( 60 ),
        nivel 			INT,
        categoria 		INT
        );
        
	CREATE TABLE Asignacion (
		emp 			INT,
        hot 			INT,
        fIni 			DATE,
        dias 			INT
        );       
#-------------------------------------------------------------------------------------------------------------
#	AGREGACIÓN DE DATOS
#-------------------------------------------------------------------------------------------------------------
	INSERT INTO Empleado 	VALUES	( 100, 'Fulgencia',	   10.40, 'Dirección', 							NULL ),
									( 101, 'Terasia', 	   10.40, 'Dirección', 							NULL ),
									( 102, 'Fulgencio',     9.76, 'Gerente', 							100 ),
                                    ( 103, 'Terasio',	    9.76, 'Gerente', 							101 ),
									( 104, 'Guillermina',   7.90, 'Recepción', 							102 ),
									( 105, 'Guillermino',   7.90, 'Recepción', 							103 ),
									( 106, 'Pancracia',     8.45, 'Jefe de Planta', 					102 ),
                                    ( 107, 'Austraberta',   8.45, 'Jefe de Planta', 					103 ),
									( 108, 'Pancracio',     7.95, 'Jefe de servicio de habitaciones', 	106 ),
                                    ( 109, 'Austraberto',   7.95, 'Jefe de servicio de habitaciones', 	107 ),
									( 110, 'Eulalia',       5.45, 'Servicio de limpieza', 				106 ),
									( 111, 'Eulalio',       5.45, 'Servicio de limpieza', 				106 ),
									( 112, 'Humbelida',     5.45, 'Servicio de limpieza', 				106 ),
									( 113, 'Humbelido',     5.45, 'Servicio de limpieza', 				107 ),
									( 114, 'Ludana',        5.45, 'Servicio de limpieza', 				107 ),
									( 115, 'Ludano',        5.45, 'Servicio de limpieza', 				107 );
    
    INSERT INTO Hotel 		VALUES	( 200, 'MEJOR SERVICIO', 'Rúa de abaixo, 50', 	'ALTO STANDING', 	5, 1 ),
									( 201, 'BUENAS VACACIONES', 'Rúa de arriba, 40', 'TURISTAS', 		1, 1 );

	INSERT INTO asignacion	VALUES	( 100, 200, '2020-01-01', NULL ),
									( 101, 201, '2020-01-02', NULL ),
                                    ( 102, 200, '2020-01-01', 365 ),
                                    ( 102, 200, '2021-01-01', NULL ),
                                    ( 103, 201, '2020-01-02', 90 ),
                                    ( 103, 201, '2020-04-02', 90 ),
                                    ( 103, 201, '2020-07-02', NULL ),
                                    ( 104, 200, '2020-01-01', 1000 ),
                                    ( 105, 201, '2020-01-01', 500 ),
                                    ( 105, 201, '2021-05-16', 500 ),
                                    ( 106, 200, '2020-01-01', NULL ),
                                    ( 107, 201, '2020-01-02', NULL ),
                                    ( 108, 200, '2020-01-01', 2000 ),
                                    ( 109, 201, '2020-01-02', 1800 ),
                                    ( 110, 200, '2020-01-01', 1500 ),
                                    ( 111, 201, '2020-01-02', 1400 ),
                                    ( 112, 200, '2020-01-01', 1500 ),
                                    ( 113, 201, '2020-01-02', 1400 );
#-------------------------------------------------------------------------------------------------------------
#	CREACIÓN DE LAS CLAVES PRIMARIAS
#-------------------------------------------------------------------------------------------------------------
	alter table Empleado 	ADD CONSTRAINT PK_Empleado		PRIMARY KEY	( codEmp );
	alter table Hotel 		ADD CONSTRAINT PK_Hotel			PRIMARY KEY	( cdHotel );
	alter table Asignacion 	ADD CONSTRAINT PK_Asignacion	PRIMARY KEY	( emp, hot, fIni );
#-------------------------------------------------------------------------------------------------------------
#	CREACIÓN DE LAS CLAVES FORÁNEAS
#-------------------------------------------------------------------------------------------------------------
	alter table Empleado	ADD CONSTRAINT FK_Emp_Sup				FOREIGN KEY( supervisor )	REFERENCES Empleado( codEmp );
    alter table Asignacion	ADD CONSTRAINT FK_Empleado_Asignacion 	FOREIGN KEY( emp )			REFERENCES Empleado( codEmp );
    alter table Asignacion  ADD CONSTRAINT FK_Hotel_Asignacion 		FOREIGN KEY( hot )			REFERENCES Hotel( CdHotel );
#-------------------------------------------------------------------------------------------------------------
#	MODIFICACIÓN DE LA CLAVE PRIMARIA DE HOTEL A 'codHotel'
#-------------------------------------------------------------------------------------------------------------
	alter table Hotel		RENAME COLUMN cdHotel	TO	codHotel;
#-------------------------------------------------------------------------------------------------------------
#	CAMBIA LOS NOMBRES DE LAS TABLAS A PLURAL
#-------------------------------------------------------------------------------------------------------------
	alter table Empleado	RENAME TO	Empleados;
    alter table Hotel		RENAME TO	Hoteles;
    alter table Asignacion 	RENAME TO	Asignaciones;
#-------------------------------------------------------------------------------------------------------------
#	IMPIDE QUE QUEDEN VACÍOS TODOS LOS ATRIBUTOS, SALVO LOS ESTRICTAMENTE NECESARIOS
#-------------------------------------------------------------------------------------------------------------
	alter table empleados		MODIFY Nombre		VARCHAR( 60 )		NOT NULL,
								MODIFY pagoXhora	DECIMAL( 18, 2 )	NOT NULL,
								MODIFY profesion 	VARCHAR( 60 )		NOT NULL;
    alter table hoteles			MODIFY nombre		VARCHAR( 30 )		NOT NULL,
								MODIFY direccion	VARCHAR( 60 )		NOT NULL,
								MODIFY tipo			VARCHAR( 60 )		NOT NULL,
								MODIFY nivel		INT					NOT NULL,
								MODIFY categoria	INT					NOT NULL;
#-------------------------------------------------------------------------------------------------------------
#	MODIFICACIÓN DE LOS ATRIBUTOS DE LA TABLA ASIGNACIÓN POR OTROS MÁS SIGNIFICATIVOS
#-------------------------------------------------------------------------------------------------------------
	alter table asignaciones	RENAME COLUMN emp	TO codEmp;
    alter table asignaciones	RENAME COLUMN hot	TO hotel;
	alter table asignaciones	RENAME COLUMN fIni	TO FechaInicio;
#-------------------------------------------------------------------------------------------------------------
#	CONSULTAS
#-------------------------------------------------------------------------------------------------------------
#	1. Muestra el código de los empleados, su nombre, profesión y su supervisor
		SELECT codEmp, nombre, profesion, supervisor from empleados;
#-------------------------------------------------------------------------------------------------------------      
#  2. Muesta el nombre de cada empleado con el de su supervisor
		SELECT e.nombre as 'EMPLEADO', s.nombre as 'SUPERVISOR' from empleados e, empleados s 
			where e.supervisor = s.codEmp;
#-------------------------------------------------------------------------------------------------------------
#  3. Muestra los trabajadores agrupados por el nombre del hotel en el que trabajan
		select empleados.nombre, hoteles.nombre  from empleados, asignaciones, hoteles 
			where empleados.codEmp = asignaciones.codEmp and hotel = codHotel;
            
		select empleados.nombre, hoteles.nombre  from empleados  JOIN asignaciones  JOIN hoteles 
			ON empleados.codEmp = asignaciones.codEmp and hotel = codHotel;
#-------------------------------------------------------------------------------------------------------------
#  4. Muestra los empleados cuyo nombre empiece por vocal
		select nombre from empleados 
			where nombre REGEXP '^[aeou]';
#-------------------------------------------------------------------------------------------------------------
#  5. Muestra los empleados cuyo nombre no tenga la vocal 'i'
		select nombre from empleados where nombre NOT LIKE '%i%';
		select nombre from empleados where nombre NOT REGEXP 'i';
#-------------------------------------------------------------------------------------------------------------
#  6. Muestra los empleados con contrato indefinido
		select nombre from empleados where codEmp IN (
			select codEmp from asignaciones where dias IS NULL );
#-------------------------------------------------------------------------------------------------------------
#  7. Muestra los empleados con el contrato temporal de mayor duración
		select nombre from empleados where codEmp IN (
			select codEmp from asignaciones where dias = (select max(dias) from asignaciones)
            );
#-------------------------------------------------------------------------------------------------------------
#  8. Muestra los empleados con los contratos de menor duración, estén o no vigentes
		select nombre from empleados where codEmp IN (
			select codEmp from asignaciones where dias = (select min(dias) from asignaciones)
            );
#-------------------------------------------------------------------------------------------------------------
#  9. Muestra el pago por horas de cada puesto de trabajo del hotel
        select profesion, pagoXhora from empleados group by profesion;
#-------------------------------------------------------------------------------------------------------------
# 10. Muestra el gasto por hora de cada hotel en empleados
		select sum( pagoXhora )/2 from empleados;
#-------------------------------------------------------------------------------------------------------------
# 11. Muestra los empleados que no han tenido ninguna asignación a hoteles
		select * from empleados where codEmp NOT IN (select codEmp from asignaciones);
#-------------------------------------------------------------------------------------------------------------
# 12. Muestra los empleados con las fechas de sus últimos contratos
        select 	(select distinct(nombre) from empleados where empleados.codEmp = asignaciones.codEmp) AS 'Empleado', 
				(select nombre from hoteles where codhotel = hotel) AS 'Hotel', 
                max(FechaInicio) AS 'Último contrato' from asignaciones  group by codEmp;
#-------------------------------------------------------------------------------------------------------------
# 13. Muestra el gasto medio por trabajador esté o no contratados
		select avg( pagoXhora ) from empleados;
#-------------------------------------------------------------------------------------------------------------
# 14. Muestra el gasto medio por trabajador de los que estén contratados
		select avg( pagoXhora ) from empleados where codEmp IN (select codEmp from asignaciones);
#-------------------------------------------------------------------------------------------------------------
# 15. Muestra los trabajadores que cobren más que la media del punto 13
		select *  from empleados where pagoXhora > (select avg( pagoXhora ) from empleados);
#-------------------------------------------------------------------------------------------------------------
# 16. Muestra los puestos de trabajo que cobren menos que la media del punto 14.
		select distinct(profesion), pagoXhora from empleados where pagoXhora < 
			(select avg( pagoXhora ) from empleados where codEmp IN 
					(select codEmp from asignaciones) );
#-------------------------------------------------------------------------------------------------------------
SELECT * FROM empleados;
select * from hoteles;
select * from asignaciones;
describe empleados;
describe hoteles;
describe asignaciones;