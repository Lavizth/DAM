USE 					Diamantes;
#--------------------------------------------------------------------------------------------------------
# 1. Muestra toda la información de los diamantes
#--------------------------------------------------------------------------------------------------------
select * from diamante;
#--------------------------------------------------------------------------------------------------------
# 2. Muestra cuántos diamantes hay
#--------------------------------------------------------------------------------------------------------
select count(*) from diamante;
#--------------------------------------------------------------------------------------------------------
# 3. Muestra el tipo de corte, el número de diamantes en cada tipo, la suma de sus precios, los precios máximo, medio y mínimo de cada tipo de corte.
#--------------------------------------------------------------------------------------------------------
select corte, count(*), sum(precio), max(precio), avg(precio), min(precio) from diamante group by corte;
#--------------------------------------------------------------------------------------------------------
# 4. Muestra los diamantes de mayor precio
#--------------------------------------------------------------------------------------------------------
select * from diamante where precio = 
		(select max(precio) from diamante);
#--------------------------------------------------------------------------------------------------------
# 5. Muestra los diamanted de menor precio
#--------------------------------------------------------------------------------------------------------
select * from diamante where precio = 
		(select min(precio) from diamante);
#--------------------------------------------------------------------------------------------------------
# 6. Muestra los diamantes de color 'D'
#--------------------------------------------------------------------------------------------------------
select * from (select * from diamante where color = 'D') as T1;
#--------------------------------------------------------------------------------------------------------
# 7. Muestra los diagramas de las tablas comprendidas entre la 50 y 55
#--------------------------------------------------------------------------------------------------------
select * from diamante where id IN (select id from diamante where profundidad between 50 and 55);
#--------------------------------------------------------------------------------------------------------
# 8. ¿Cuánto cuesta el más caro en la lista anterior?
#--------------------------------------------------------------------------------------------------------
select max(precio) from diamante where profundidad between 50 and 55;

select * from diamante where id IN 
	(select id from diamante where profundidad between 50 and 55) order by precio desc limit 1;
select * from (select * from diamante where profundidad between 50 and 59) as T1 
	where precio = (select max(precio) from diamante where profundidad between 50 and 55);
#--------------------------------------------------------------------------------------------------------
# 8. ¿Cuánto cuesta el más barato en la lista anterior?
#--------------------------------------------------------------------------------------------------------
select min(precio) from diamante where profundidad between 50 and 55;

select * from diamante where id IN 			# SÓLO MUESTRA UNO
	(select id from diamante where profundidad between 50 and 55) order by precio asc limit 1;
select * from (select * from diamante where profundidad between 50 and 59) as T1 
	where precio = (select min(precio) from diamante where profundidad between 50 and 55);
#--------------------------------------------------------------------------------------------------------
# 9. Muestra el tipo de corte, el número de diamantes en cada tipo, la suma de sus precios, los precios máximo, medio y mínimo de cada tipo de color.
#--------------------------------------------------------------------------------------------------------
select color, count(*), sum(precio), max(precio), avg(precio), min(precio) from diamante group by color;

