USE 					Titanic;
#---------------------------------------------------------------------------------------------------
# 1. Muestra los datos de todos los pasajeros
#---------------------------------------------------------------------------------------------------
select * from pasajeros;
#---------------------------------------------------------------------------------------------------
# 2. ¿Cuántos pasajeros hay en total?
#---------------------------------------------------------------------------------------------------
select count(*) AS 'Pasajeros' from pasajeros;
#---------------------------------------------------------------------------------------------------
# 3. ¿Cuántos supervivientes quedaron al total?
#---------------------------------------------------------------------------------------------------
select count(*) AS 'Supervivientes' from pasajeros where survived = 1;
#---------------------------------------------------------------------------------------------------
# 4. ¿Cuántos superviviente fueron por clases sociales?
#---------------------------------------------------------------------------------------------------
select count(*) AS 'Supervivientes', pclass as 'Clase social' from pasajeros where survived = 1 group by pclass;
#---------------------------------------------------------------------------------------------------
# 5. ¿Cuántos supervivientes atendiendo a clases sociales y sexo?
#---------------------------------------------------------------------------------------------------
select count(*) AS 'Supervivientes', pclass as 'Clase social', sex as 'Sexo' from pasajeros where survived = 1 group by pclass, sex;
#---------------------------------------------------------------------------------------------------
# 6. ¿Cuántos supervivientes atendiendo a clases sociales, sexo y edad?
#---------------------------------------------------------------------------------------------------
select count(*) AS 'Supervivientes', pclass as 'Clase social', sex as 'Sexo', age as 'Edad' from pasajeros where survived = 1 
	group by pclass, sex, age order by age, pclass, sex;
#---------------------------------------------------------------------------------------------------
# 7. ¿Qué pasajeros se salvaron con mayor edad?
#---------------------------------------------------------------------------------------------------
select * from pasajeros where age = ( select max( age ) from pasajeros where survived = 1 );
#---------------------------------------------------------------------------------------------------
# 8. ¿Qué pasajeros se salvaron con menor edad?
#---------------------------------------------------------------------------------------------------
select * from pasajeros where age = ( select max( age ) from pasajeros where survived = 0 );
#---------------------------------------------------------------------------------------------------
# 9. Muestra la edad del mayor superviviente y también la edad del mayor fallecido.
#---------------------------------------------------------------------------------------------------
select 	( select max( age ) from pasajeros where survived = 1 ) as 'Mayor superviviente', 
		( select max( age ) from pasajeros where survived = 0 ) as 'Mayor no superviviente';
#---------------------------------------------------------------------------------------------------
# 10. ¿Cuántos embarcados según clase social y sexo?
#---------------------------------------------------------------------------------------------------
 select Pclass, Sex, count(*) from pasajeros group by Pclass, Sex;
#---------------------------------------------------------------------------------------------------
# 11. Lista los pasajeros clasificados en función de clase social y sexo.
#---------------------------------------------------------------------------------------------------
 select * from pasajeros order by Pclass, sex;
#---------------------------------------------------------------------------------------------------
# 12. Haz una vista con el número de pasajeros que hay en cada cabina, según clase la social y el sexo.
#---------------------------------------------------------------------------------------------------
create view ClaseSocialSexoPorCabina As select Cabin, pclass, sex, count(*) from pasajeros group by cabin, pclass, sex;
#---------------------------------------------------------------------------------------------------
# 13. Crea una vista para cada clase social
#---------------------------------------------------------------------------------------------------
CREATE VIEW Clase_1 AS Select * from pasajeros where pclass = 1;
CREATE VIEW Clase_2 AS Select * from pasajeros where pclass = 2;
CREATE VIEW Clase_3 AS Select * from pasajeros where pclass = 3;
select * from Clase_1;
#---------------------------------------------------------------------------------------------------
# 14. ¿Qué cabina fue la que más fallecidos tuvo y cuántos?
#---------------------------------------------------------------------------------------------------
select cabin, count(*) from Pasajeros where survived = 0 group by cabin order by 2 desc limit 1;
#---------------------------------------------------------------------------------------------------
# 15. ¿En qué cabinas estaban los pasajeros de primera clase?
#---------------------------------------------------------------------------------------------------
select distinct(Cabin) from pasajeros where Pclass = 1;
#---------------------------------------------------------------------------------------------------
# 16. ¿En qué cabinas estaban los pasajeros de tercera clase?
#---------------------------------------------------------------------------------------------------
select distinct(Cabin) from pasajeros where Pclass = 3;
#---------------------------------------------------------------------------------------------------
# 17. Haz una estadística de los pasajeros de entre 20 y 30 años. Analizando su supervivencia en función de su sexo y clase social
#---------------------------------------------------------------------------------------------------
 select Age, Pclass, Sex, count(*) as 'Pasajeros' from pasajeros group by Age, Pclass, sex, Survived having age between 20 AND 30 and survived = 1
		order by age, pclass, sex;

CREATE VIEW Edad2030	AS Select * from Pasajeros where age between 20 AND 30;
CREATE VIEW Salvados 	AS Select * from Edad2030 where survived = 1;
CREATE VIEW Fallecidos	AS Select * from Edad2030 where survived = 0;

select Pclass, count( * ) AS 'Supervivientes', count(*)*100/(select count(*) from Edad2030 where Edad2030.Pclass = Salvados.Pclass) as "%" from Salvados 
	group by Pclass order by Pclass;
select sex, count( * ) AS 'Supervivientes', count(*)*100/(select count(*) from Edad2030 where Edad2030.sex = Salvados.sex) as "%" from Salvados 
	group by sex Order by sex;

select Pclass, sex, count( * ) AS 'Supervivientes', count(*)*100/(select count(*) from Edad2030 where Edad2030.Pclass = Salvados.Pclass and Edad2030.sex = Salvados.sex) as "%" from Salvados 
	group by Pclass, sex order by Pclass, sex;






