drop database if exists CorteTeis;
create database CorteTeis;
use CorteTeis;
create table Departamento (
 CodigoCliente VARCHAR(10),
 Telefono varchar(20),
 Nombre varchar(50),
 Presupuesto int 
);
create table CentroTrabajo (
 Nombre varchar(50),
 CodigoTrabajo VARCHAR(10),
 Telefono varchar(20),
 Direccion varchar(40) 
);
create table Empleados (
 Nombre varchar(50),
 NIF varchar(9),
 Apellidos varchar(50),
 Telefono varchar(20),
 Salario numeric 
);
create table Hijos (
 Nombre varchar(50),
 Apellidos varchar(20),
 FechaNacimiento date,
 CodigoHijos VARCHAR(5) 
);
create table Habilidades (
 Nombre varchar(50),
 CodigoHabidad VARCHAR(10),
 Descripcion varchar(255) 
);