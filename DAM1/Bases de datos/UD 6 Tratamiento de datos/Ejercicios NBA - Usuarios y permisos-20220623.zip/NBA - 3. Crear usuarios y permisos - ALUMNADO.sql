#--------------------------------------------------------------------------------------------
#	UTILIZACIÓN DE LA Base de Datos 'NBA'
#--------------------------------------------------------------------------------------------
	USE NBA;
#--------------------------------------------------------------------------------------------
#	1. 	BORRAMOS Y CREAMOS LOS USUARIOS: hay 2 Conferencias (East, West) y 3 divisiones en cada una (Atlantic, SouthEast, Central) y (Pacific, SouthWest, NorthWest)
#--------------------------------------------------------------------------------------------
    DROP USER IF EXISTS Fulgencio;		CREATE USER 	Fulgencio	IDENTIFIED BY	'abc';		# Todo
    DROP USER IF EXISTS Fulgencia;		CREATE USER 	Fulgencia	IDENTIFIED BY	'abc';		# Todo
    DROP USER IF EXISTS Guillermino;	CREATE USER 	Guillermino	IDENTIFIED BY	'abc';		# Conferencia East
    DROP USER IF EXISTS Guillermina;	CREATE USER 	Guillermina	IDENTIFIED BY	'abc';		# Conferencia East
    DROP USER IF EXISTS Pancracio;		CREATE USER 	Pancracio	IDENTIFIED BY	'abc';		# Conferencia West
    DROP USER IF EXISTS Pancracia;		CREATE USER 	Pancracia	IDENTIFIED BY	'abc';		# Conferencia West
    DROP USER IF EXISTS Filomeno;		CREATE USER 	Filomeno	IDENTIFIED BY	'abc';		# División Atlantic
    DROP USER IF EXISTS Filomena;		CREATE USER 	Filomena	IDENTIFIED BY	'abc';		# División Atlantic
    DROP USER IF EXISTS Anaximandro;	CREATE USER 	Anaximandro	IDENTIFIED BY	'abc';		# División SouthEast
    DROP USER IF EXISTS Anaximandra;	CREATE USER 	Anaximandra	IDENTIFIED BY	'abc';		# División SouthEast
    DROP USER IF EXISTS Romino;			CREATE USER 	Romino		IDENTIFIED BY	'abc';		# División Central
    DROP USER IF EXISTS Romina;			CREATE USER 	Romina		IDENTIFIED BY	'abc';		# División Pacific
    DROP USER IF EXISTS Agapito;		CREATE USER 	Agapito		IDENTIFIED BY	'abc';		# División Pacific
    DROP USER IF EXISTS Agapita;		CREATE USER 	Agapita		IDENTIFIED BY	'abc';		# División SouthWest
    DROP USER IF EXISTS Apolonio;		CREATE USER 	Apolonio	IDENTIFIED BY	'abc';		# División SouthWest
    DROP USER IF EXISTS Apolonia;		CREATE USER		Apolonia	IDENTIFIED BY	'abc';		# División NorthWest
#--------------------------------------------------------------------------------------------
#	2. BORRAMOS Y CREAMOS LAS VISTAS
#--------------------------------------------------------------------------------------------
    DROP VIEW IF EXISTS NBA_EQUIPOS;					CREATE VIEW NBA_EQUIPOS						AS SELECT * FROM NBA.equipos;
    DROP VIEW IF EXISTS NBA_JUGADORES;					CREATE VIEW	NBA_JUGADORES					AS SELECT * FROM NBA.jugadores;
    DROP VIEW IF EXISTS NBA_ESTADISTICAS;				CREATE VIEW NBA_ESTADISTICAS				AS SELECT * FROM NBA.estadisticas;
    DROP VIEW IF EXISTS NBA_PARTIDOS;					CREATE VIEW NBA_PARTIDOS					AS SELECT * FROM NBA.partidos;
    
    DROP VIEW IF EXISTS CONFERENCIA_ESTE_EQUIPOS;		CREATE VIEW CONFERENCIA_ESTE_EQUIPOS		AS SELECT * FROM NBA.equipos 		where Conferencia = 'East';
    DROP VIEW IF EXISTS CONFERENCIA_ESTE_JUGADORES;		CREATE VIEW	CONFERENCIA_ESTE_JUGADORES		AS SELECT * FROM NBA.jugadores 		where Equipo	  IN (select nombre from CONFERENCIA_ESTE_EQUIPOS);
    DROP VIEW IF EXISTS CONFERENCIA_ESTE_ESTADISTICAS;	CREATE VIEW CONFERENCIA_ESTE_ESTADISTICAS	AS SELECT * FROM NBA.estadisticas	where jugador 	  IN (select codigo from CONFERENCIA_ESTE_JUGADORES);
    DROP VIEW IF EXISTS CONFERENCIA_ESTE_PARTIDOS;		CREATE VIEW CONFERENCIA_ESTE_PARTIDOS		AS SELECT * FROM NBA.partidos		where EquipoLocal IN (select nombre from CONFERENCIA_ESTE_EQUIPOS) AND EquipoVisitante IN (select nombre from CONFERENCIA_ESTE_EQUIPOS);
    
/*	CONFERENCIA OESTE	*/
    
    DROP VIEW IF EXISTS DIVISION_ATLANTICA_EQUIPOS;		CREATE VIEW	DIVISION_ATLANTICA_EQUIPOS		AS SELECT * FROM NBA.equipos		where Division = 'Atlantic';
    DROP VIEW IF EXISTS DIVISION_ATLANTICA_JUGADORES;	CREATE VIEW	DIVISION_ATLANTICA_JUGADORES	AS SELECT * FROM NBA.jugadores		where Equipo 	  IN (select nombre from DIVISION_ATLANTICA_EQUIPOS);
    DROP VIEW IF EXISTS DIVISION_ATLANTICA_ESTADISTICAS;CREATE VIEW	DIVISION_ATLANTICA_ESTADISTICAS	AS SELECT * FROM NBA.estadisticas	where jugador 	  IN (select codigo from DIVISION_ATLANTICA_JUGADORES);
    DROP VIEW IF EXISTS DIVISION_ATLANTICA_PARTIDOS;	CREATE VIEW	DIVISION_ATLANTICA_PARTIDOS		AS SELECT * FROM NBA.PARTIDOS		where EquipoLocal IN (select nombre from DIVISION_ATLANTICA_EQUIPOS) AND EquipoVisitante IN (select nombre from DIVISION_ATLANTICA_EQUIPOS);

/*	DIVISION SUDESTE	*/

/*	DIVISION CENTRAL	*/

/*	DIVISION PACIFICO	*/

/*	DIVISION SUDOESTE	*/

/*	DIVISION NOROESTE	*/
#--------------------------------------------------------------------------------------------
#	3. ASIGNAMOS PRIVILEGIOS (O PERMISOS) A LOS ROLES
#	Un rol es un grupo al que se le van a asignar los mismos derechos. En lugar de asignar los derechos individualmente a cada usuario, 
#	se pueden crear grupos que tendrán los derechos y a continuación asignar los usuarios a un grupo. 
#			Este concepto de rol no existe actualmente en MySQL.
#--------------------------------------------------------------------------------------------
	GRANT ALL 	ON	NBA_EQUIPOS							TO	Fulgencio, Fulgencia;
	GRANT ALL 	ON	NBA_JUGADORES						TO	Fulgencio, Fulgencia;
	GRANT ALL 	ON	NBA_ESTADISTICAS					TO	Fulgencio, Fulgencia;
	GRANT ALL 	ON	NBA_PARTIDOS						TO	Fulgencio, Fulgencia;

	GRANT ALL 	ON	CONFERENCIA_ESTE_EQUIPOS			TO	Guillermino, Guillermina;
	GRANT ALL 	ON	CONFERENCIA_ESTE_JUGADORES			TO	Guillermino, Guillermina;
	GRANT ALL 	ON	CONFERENCIA_ESTE_ESTADISTICAS		TO	Guillermino, Guillermina;
	GRANT ALL 	ON	CONFERENCIA_ESTE_PARTIDOS			TO	Guillermino, Guillermina;

/*	PERMISOS CONFERENCIA OESTE	*/

	GRANT ALL 	ON	DIVISION_ATLANTICA_EQUIPOS			TO	Filomeno, Filomena;
	GRANT ALL 	ON	DIVISION_ATLANTICA_JUGADORES		TO	Filomeno, Filomena;
	GRANT ALL 	ON	DIVISION_ATLANTICA_ESTADISTICAS		TO	Filomeno, Filomena;
	GRANT ALL 	ON	DIVISION_ATLANTICA_PARTIDOS			TO	Filomeno, Filomena;

/*	PERMISOS DIVISION SUDESTE	*/

/*	PERMISOS DIVISION CENTRAL	*/

/*	PERMISOS DIVISION PACIFICO	*/

/*	PERMISOS DIVISION SUDOESTE	*/

/*	PERMISOS DIVISION NOROESTE	*/
#--------------------------------------------------------------------------------------------
#	4. ASIGNAMOS ROLES A LOS USUARIOS
#--------------------------------------------------------------------------------------------
    flush privileges;
