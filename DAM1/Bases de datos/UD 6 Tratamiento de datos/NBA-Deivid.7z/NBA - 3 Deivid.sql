#--------------------------------------------------------------------------------------------
#	UTILIZACIÓN DE LA Base de Datos 'NBA'
#--------------------------------------------------------------------------------------------
use NBA;
#--------------------------------------------------------------------------------------------
#	CREAMOS LOS USUARIOS: hay 2 Conferencias (East, West) y 3 divisiones en cada una (Atlantic, SouthEast, Central) y (Pacific, SouthWest, NorthWest)
#--------------------------------------------------------------------------------------------
#	NOMBRE			CLAVE			 ACCESO
#--------------------------------------------------------------------------------------------
#	Fulgencio		'abc'			 Todo
#   Fulgencia		'abc'			 Todo
#	Guillermino		'abc'			 Conferencia East
#	Guillermina		'abc'			 Conferencia East
#	Pancracio		'abc'			 Conferencia West
#	Pancracia		'abc'			 Conferencia West
#	Filomeno		'abc'			 División Atlantic
#	Filomena		'abc'			 División Atlantic
#	Anaximandro		'abc'			 División SouthEast
#	Anaximandra		'abc'			 División SouthEast
#	Romino			'abc'			 División Central
#	Romina			'abc'			 División Pacific
#	Agapito			'abc'			 División Pacific
#	Agapita			'abc'			 División SouthWest
#	Apolonio		'abc'			 División SouthWest
#	Apolonia		'abc'			 División NorthWest
#--------------------------------------------------------------------------------------------
create user Fulgencio 	identified by "abc";
create user Fulgencia 	identified by "abc";
create user Guillermino identified by "abc";
create user Guillermina identified by "abc";
create user Pancracio 	identified by "abc";
create user Pancracia 	identified by "abc";
create user Filomeno 	identified by "abc";
create user Filomena 	identified by "abc";
create user Anaximandro identified by "abc";
create user Anaximandra identified by "abc";
create user Romino 		identified by "abc";
create user Romina 		identified by "abc";
create user Agapito 	identified by "abc";
create user Agapita 	identified by "abc";
create user Apolonio 	identified by "abc";
create user Apolonia 	identified by "abc";
#--------------------------------------------------------------------------------------------
#	CREAMOS LOS PERMISOS:
#--------------------------------------------------------------------------------------------
grant all on * to Fulgencio;
grant all on * to Fulgencia;

create view Conferencias_East as select * from Equipos where Conferencia = "East";
grant all on Conferencias_East to Guillermino;
grant all on Conferencias_East to Guillermina;

create view Conferencias_West as select * from Equipos where Conferencia = "West";
grant all on Conferencias_West to Pancracio;
grant all on Conferencias_West to Pancracia;

create view Division_Atlantic as select * from Equipos where Division = "Atlantic";
grant all on Division_Atlantic to Filomeno;
grant all on Division_Atlantic to Filomena;

create view Division_SouthEast as select * from Equipos where Division = "SouthEast";
grant all on Division_SouthEast to Anaximandro;
grant all on Division_SouthEast to Anaximandra;

create view Division_Central as select * from Equipos where Division = "Central";
grant all on Division_Central to Romino;

create view Division_Pacific as select * from Equipos where Division = "Pacific";
grant all on Division_Pacific to Romina;
grant all on Division_Pacific to Agapito;

create view Division_SouthWest as select * from Equipos where Division = "SouthWest";
grant all on Division_SouthWest to Agapita;
grant all on Division_SouthWest to Apolonio;

create view Division_NorthWest as select * from Equipos where Division = "NorthWest";
grant all on Division_NorthWest to Apolonia;

#select user from mysql.user;
#show grants for Apolonia;