#--------------------------------------------------------------------------------------------
#	UTILIZACIÓN DE LA Base de Datos 'NBA'
#--------------------------------------------------------------------------------------------
use NBA;
#--------------------------------------------------------------------------------------------
#	AGREGAR 'Equipos'
#--------------------------------------------------------------------------------------------
#	INICIAR TRANSACCIÓN
start transaction;
		INSERT INTO equipos VALUES ('Celtics','Boston','East','Atlantic');
		INSERT INTO equipos VALUES ('Raptors','Toronto','East','Atlantic');
		INSERT INTO equipos VALUES ('76ers','Philadelphia','East','Atlantic');
		INSERT INTO equipos VALUES ('Nets','New Jersey','East','Atlantic');
		INSERT INTO equipos VALUES ('Knicks','New York','East','Atlantic');
		INSERT INTO equipos VALUES ('Pistons','Detroit','East','Central');
#	PRIMER PUNTO DE SEGURIDAD 'Equipos_1'
savepoint Equipos_1;
		
        INSERT INTO equipos VALUES ('Cavaliers','Cleveland','East','Central');
		INSERT INTO equipos VALUES ('Pacers','Indiana','East','Central');
		INSERT INTO equipos VALUES ('Bulls','Chicago','East','Central');
		INSERT INTO equipos VALUES ('Bucks','Milwaukee','East','Central');
		INSERT INTO equipos VALUES ('Magic','Orlando','East',SouthEast);			# Sin comillas
		INSERT INTO equipos VALUES ('Wizards','Washington','East','SouthEast');
		INSERT INTO equipos VALUES ('Hawks','Atlanta','East','SouthEast');
		INSERT INTO equipos VALUES ('Bobcats','Charlotte','East','SouthEast');
		INSERT INTO equipos VALUES ('Heat','Miami','East','SouthEast');
#	SEGUNDO PUNTO DE SEGURIDAD 'Equipos_2'
savepoint Equipos_2;
		
        INSERT INTO equipos VALUES ('Jazz','Utah','West','NorthWest');
		INSERT INTO equipos VALUES ('Nuggets','Denver','West','NorthWest');
		INSERT INTO equipos VALUES ('Trail Blazers','Portland','West','NorthWest');
		INSERT INTO equipos VALUES ('Timberwolves','Minnesota','West','NorthWest');
		INSERT INTO equipos VALUES ('Supersonics','Seattle','West','NorthWest');
		INSERT INTO equipos VALUES ('Lakers','Los Angeles','West','Pacific');
		INSERT INTO equipos VALUES ('Suns','Phoenix','West','Pacific');
#	TERCER PUNTO DE SEGURIDAD 'Equipos_3'
savepoint Equipos_3;

		INSERT INTO equipos VALUES ('Warriors','Golden State','West','Pacific');
		INSERT INTO equipos VALUES ('Kings','Sacramento','West','Pacific');
		INSERT INTO equipos VALUES ('Clippers','Los Angeles','West','Pacific');
		INSERT INTO equipos VALUES ('Hornets','New Orleans','West','SouthWest');
		INSERT INTO equipos VALUES ('Spurs','San Antonio','West',SouthWest);		# Sin comillas
		INSERT INTO equipos VALUES ('Rockets','Houston','West','SouthWest');
		INSERT INTO equipos VALUES ('Mavericks','Dallas','West','SouthWest');
		INSERT INTO equipos VALUES ('Grizzlies','Memphis','West','SouthWest');
#	FINALIZAR TRANSACCIÓN COMUNICANDO QUE TODO HA IDO BIEN
commit;

#--------------------------------------------------------------------------------------------
#	1. Ejecuta este fichero y comprueba que da un error
#--------------------------------------------------------------------------------------------
#	Al ejecutar el fichero da el siguiente error: Error Code: 1054. Unknown column 'SouthEast' in 'field list'
#--------------------------------------------------------------------------------------------
#	2. Muestra los datos introducidos
#--------------------------------------------------------------------------------------------~
#Se introdujeron los datos hasta la linea 20: INSERT INTO equipos VALUES ('Magic','Orlando','East',SouthEast);
select * from equipos;
#--------------------------------------------------------------------------------------------
#	3. Restaura la base de datos al punto de seguridad inmediatamente anterior al error
#--------------------------------------------------------------------------------------------
rollback to Equipos_1;
#--------------------------------------------------------------------------------------------
#	4. Muestra los datos tras la restauración del punto de seguridad
#--------------------------------------------------------------------------------------------
select * from equipos;
#--------------------------------------------------------------------------------------------
#	5. Copia el código que ejecutarás tras la restauración de la base de datos al punto de seguridad
#--------------------------------------------------------------------------------------------
start transaction;
        INSERT INTO equipos VALUES ('Cavaliers','Cleveland','East','Central');
		INSERT INTO equipos VALUES ('Pacers','Indiana','East','Central');
		INSERT INTO equipos VALUES ('Bulls','Chicago','East','Central');
		INSERT INTO equipos VALUES ('Bucks','Milwaukee','East','Central');
		INSERT INTO equipos VALUES ('Magic','Orlando','East',"SouthEast");			# Error corregido
		INSERT INTO equipos VALUES ('Wizards','Washington','East','SouthEast');
		INSERT INTO equipos VALUES ('Hawks','Atlanta','East','SouthEast');
		INSERT INTO equipos VALUES ('Bobcats','Charlotte','East','SouthEast');
		INSERT INTO equipos VALUES ('Heat','Miami','East','SouthEast');
#	SEGUNDO PUNTO DE SEGURIDAD 'Equipos_2'
savepoint Equipos_2;
		
        INSERT INTO equipos VALUES ('Jazz','Utah','West','NorthWest');
		INSERT INTO equipos VALUES ('Nuggets','Denver','West','NorthWest');
		INSERT INTO equipos VALUES ('Trail Blazers','Portland','West','NorthWest');
		INSERT INTO equipos VALUES ('Timberwolves','Minnesota','West','NorthWest');
		INSERT INTO equipos VALUES ('Supersonics','Seattle','West','NorthWest');
		INSERT INTO equipos VALUES ('Lakers','Los Angeles','West','Pacific');
		INSERT INTO equipos VALUES ('Suns','Phoenix','West','Pacific');
#	TERCER PUNTO DE SEGURIDAD 'Equipos_3'
savepoint Equipos_3;

		INSERT INTO equipos VALUES ('Warriors','Golden State','West','Pacific');
		INSERT INTO equipos VALUES ('Kings','Sacramento','West','Pacific');
		INSERT INTO equipos VALUES ('Clippers','Los Angeles','West','Pacific');
		INSERT INTO equipos VALUES ('Hornets','New Orleans','West','SouthWest');
		INSERT INTO equipos VALUES ('Spurs','San Antonio','West',SouthWest);		# Sin comillas
		INSERT INTO equipos VALUES ('Rockets','Houston','West','SouthWest');
		INSERT INTO equipos VALUES ('Mavericks','Dallas','West','SouthWest');
		INSERT INTO equipos VALUES ('Grizzlies','Memphis','West','SouthWest');
#	FINALIZAR TRANSACCIÓN COMUNICANDO QUE TODO HA IDO BIEN
commit;
#--------------------------------------------------------------------------------------------
#	6. Muestra los datos introducidos
#--------------------------------------------------------------------------------------------
select * from Equipos;
#--------------------------------------------------------------------------------------------
#	7. Restaura la base de datos al punto de seguridad inmediatamente anterior al error
#--------------------------------------------------------------------------------------------
rollback to Equipos_3;
#--------------------------------------------------------------------------------------------
#	8. Muestra los datos tras la restauración del punto de seguridad
#--------------------------------------------------------------------------------------------
select * from Equipos;
#--------------------------------------------------------------------------------------------
#	9. Copia el código que ejecutarás tras el la restauración de la base de datos al punto de seguridad
#--------------------------------------------------------------------------------------------
start transaction;
		INSERT INTO equipos VALUES ('Warriors','Golden State','West','Pacific');
		INSERT INTO equipos VALUES ('Kings','Sacramento','West','Pacific');
		INSERT INTO equipos VALUES ('Clippers','Los Angeles','West','Pacific');
		INSERT INTO equipos VALUES ('Hornets','New Orleans','West','SouthWest');
		INSERT INTO equipos VALUES ('Spurs','San Antonio','West',"SouthWest");		# Error corregido
		INSERT INTO equipos VALUES ('Rockets','Houston','West','SouthWest');
		INSERT INTO equipos VALUES ('Mavericks','Dallas','West','SouthWest');
		INSERT INTO equipos VALUES ('Grizzlies','Memphis','West','SouthWest');
#	FINALIZAR TRANSACCIÓN COMUNICANDO QUE TODO HA IDO BIEN
commit;
#--------------------------------------------------------------------------------------------
#	10. Comprueba que has introducido todos los datos correctamente
#--------------------------------------------------------------------------------------------
#Comprobamos que esta introduzido el ultimo dato y con ello todos los anteriores
select * from Equipos where Nombre = "Grizzlies";
#--------------------------------------------------------------------------------------------
#	11. Restaura los datos hasta 'Equipos_2'. ¿Por qué crees que da un error? ¿qué comando se ha ejecutado implícitamente con la confirmación de los datos introducidos?
#--------------------------------------------------------------------------------------------
rollback to Equipos_2;
#	Da error debido a que los punmtos de guardado solo existen mientras la transsaccion esta abierta, 
#	una vez ejecutado el commit la transaccion finaliza y por lo tanto los puntos de guardadon dejan de existir.
    