#--------------------------------------------------------------------------------------------
#	CREACIÓN Y USO DE LA BASE DE DATOS 'NBA'
#--------------------------------------------------------------------------------------------
drop database if exists NBA;
create database NBA;
use NBA;
#--------------------------------------------------------------------------------------------
#	CREACIÓN DE LA TABLA 'Equipos'
#--------------------------------------------------------------------------------------------
#		Nombre				cadena de texto	20, no nula
#		Ciudad				cadena de texto 20, por defecto nula
#		Conferencia			cadena de texto 4, por defecto nula
#		Division			cadena de texto 9, por defecto nula
#
#		Clave primaria		Nombre
#--------------------------------------------------------------------------------------------
create table Equipos (
	Nombre 			varchar( 20 ),
    Ciudad 			varchar( 20 ) null,
    Conferencia 	varchar( 4 ) null,
    Division 		varchar( 9 ) null,
    constraint		PK_Nombre		primary key( Nombre ),
    constraint		NoNulo_Nombre	check( Nombre is not null )
);
#--------------------------------------------------------------------------------------------
#	CREACIÓN DE LA TABLA 'Jugadores'
#--------------------------------------------------------------------------------------------
#		Codigo				entero, no nulo
#		Nombre				cadena de texto	30, por defecto nula
#		Procedencia			cadena de texto 20, por defecto nula
#		Altura				cadena de texto 4, por defecto nula
#		Peso				entero, por defecto nulo
#		Posicion			cadena de texto 5, por defecto nula
#		Equipo				cadena de texto 20, por defecto nula
#
#		Clave primaria		Codigo
#		Clave foránea		Equipo				a la tabla 'Equipos'
#--------------------------------------------------------------------------------------------
create table Jugadores (
	Codigo			int not null,
    Nombre			varchar( 30 ) null,
    Procedencia		varchar( 20 ) null,
    Altura			varchar( 4 ) null,
    Peso			int null,
    Posicion		varchar( 5 ) null,
    Equipo			varchar( 20 ) null,
    constraint		PK_Codigo				primary key( Codigo ),
    constraint		FK_Equipo				foreign key( Equipo ) 	references Equipos( Nombre ),
	constraint		NoNulo_Codigo_Jugadores	check( Codigo is not null )
);
#--------------------------------------------------------------------------------------------
#	CREACIÓN DE LA TABLA 'Estadisticas'
#--------------------------------------------------------------------------------------------
#		temporada			cadena de texto	5, no nula
#		jugador				entero, por defecto no nulo
#		PuntosXPartido		número float, por defecto nulo
#		AsistenciaXPartido	número float, por defecto nulo
#		TaponesXPartido		número float, por defecto nulo
#		ReboterXPartido		número float, por defecto nulo
#
#		Clave primaria		temporada, jugador
#		Clave foránea		jugador				a la tabla 'Jugadores'
#--------------------------------------------------------------------------------------------
create table Estadisticas (
	temporada			varchar( 5 ),
    jugador				int not null,
    PuntosXPartido		float null,
	AsistenciaXPartido	float null,
    TaponesXPartido		float null,
    ReboterXPartido		float null,
    constraint			NoNulo_Temporada	check( temporada is not null),
	constraint			PK_Jugador			primary key( temporada, jugador ),
    constraint			FK_Jugador			foreign key( jugador ) 	references Jugadores( Codigo )
);
#--------------------------------------------------------------------------------------------
#	CREACIÓN DE LA TABLA 'Partidos'
#--------------------------------------------------------------------------------------------
#		Codigo				entero, no nulo
#		equipoLocal			cadena de texto	20, por defecto nula
#		equipoVisitante		cadena de texto 20, por defecto nula
#		puntosLocal			entero, por defecto nulo
#		puntosVisitante		entero, por defecto nulo
#		temporada			cadena de texto 5, por defecto nula
#
#		Clave primaria		Codigo
#		Clave foranea		equipoLocal			a la tabla 'Equipos'
#							equipoVisitante		a la tabla 'Equipos'
#--------------------------------------------------------------------------------------------
create table Partidos (
	Codigo				int,
    equipoLocal			varchar( 20 ) null,
    equipoVisitante		varchar( 20 ) null,
    puntosLocal			int null,
    puntosVisitante		int null,
    temporada			varchar( 5 ) null,
	constraint			NoNulo_Codigo_Partidos	check( Codigo is not null ),
	constraint 			PK_Codigo				primary key( Codigo ),
    constraint			FK_EquipoLocal			foreign key( equipoLocal )		references Equipos( Nombre ),
    constraint			FK_EquipoVisitante  	foreign key( equipoVisitante )  references Equipos( Nombre )
);