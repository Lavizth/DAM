drop database if exists Hospital;
create database Hospital;
use Hospital;

create table Paciente (
 idPaciente int primary key auto_increment,
 dni varchar(12),
 nombre varchar(100),
 apellido varchar(100),
 fechaNacimiento date
);

create table Medico (
 idMedico int  primary key,
 nombre varchar( 30 ),
 apellido varchar( 30 ),
 especialidad varchar( 40 )
);

create table Atencion (
 idAtencion int primary key auto_increment,
 idPaciente int,
 idMedico int,
 informacion varchar( 50 ),
 foreign key ( idPaciente ) references Paciente( idPaciente ),
 foreign key ( idMedico )   references Medico(   idMedico )
);


# 1. Bloquea cada tabla para agregar los datos con mayor seguridad.
    
# 2. Crea transacciones para agregar los elementos de cada tabla.

# 3. Crea un par de puntos de restauracion.
	   
# 4. Crea un trigger para que cada vez que se agregue un paciente se vuelque sobre la tabla Paciente_copia

# 5. Agrega los siguientes datos en la tabla de los médicos, PERO sin indicar ningún atributo.

# 6. Agrega los siguientes datos en la tabla de los pacientes, indicando todos los atributos SALVO la clave primaria.

# 7. Agrega los siguientes datos en la tabla de las atenciones médicas, indicando todos los atributos SALVO la clave primaria.

# 8. Cambia el apellido del paciente 'Vaca' por 'Vacencio'.

# 9. Borra todos los pacientes con los identificadores 3 y 7. ¿Qué error se produce y explica a qué es debido?
    
# 10. Si deseamos borrar los pacientes del punto anterior (9), ¿qué se ha de modificar en la base de datos?

# 11. Si deseamos borrar los pacientes indicados en el punto 9 PERO manteniendo los datos asociados en la tabla Atención, ¿qué se ha de modificar en la base de datos?
    
# 12. Si deseamos borrar los pacientes indicados en el punto 9 PERO manteniendo los datos asociados en la tabla Atención, SALVO los identificadores de pacientes que deberán ser nulos, ¿qué se ha de modificar en la base de datos?
    
# 13. Copia la tabla de los médicos sobre otra nueva tabla llamada Medico_copia.
    
# 14. Crea un evento para que cada mes se borre los datos de los pacientes

# 15. Crea una vista con los pacientes que han sido atendidos por médicos de la especialidad de Urgencias.
    
# 16. Crea una vista con los Médicos ordenados en función del número de pacientes atendidos
    
# 17. Crea un usuario llamado Pancracio con contraseña 'abc' y privilegio de lectura sólo sobre la tabla Paciente.
    
# 18. Crea un guión que reúna todos estos pasos.
