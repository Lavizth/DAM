use nba;

drop table if exists equipos_backup;
create table equipos_backup (
	nombre 		varchar(20),
    ciudad 		varchar(20),
    conferencia varchar(4),
    division	varchar(9)
);
#create table equipos_backup LIKE equipos;
#-----------------------------------------------------------------
#	Copiar tabla equipos en equipos_backup con INSERT ... SELECT
#-----------------------------------------------------------------
#	insert into equipos_backup select * from equipos;
#	select * from equipos_backup;
#-----------------------------------------------------------------
#	Copiar tabla equipos en equipos_backup con PROCEDURE copiarEquipos
#-----------------------------------------------------------------
#	delimiter //
#		drop procedure if exists copiarEquipos //
#        create procedure copiarEquipos() 
#            begin
#				insert into equipos_backup select * from equipos;
#            end //
#    delimiter ;
#-----------------------------------------------------------------
#	Copiar tabla equipos en equipos_backup con FUNCTION copiarEquipos
#-----------------------------------------------------------------
#	delimiter //
#		drop function if exists copiarEquipos //
#        create function copiarEquipos() returns boolean
#			deterministic
#            begin
#				insert into equipos_backup select * from equipos;
#                return true;
#            end //
#    delimiter ;
#-----------------------------------------------------------------
#	Copiar tabla equipos en equipos_backup con CURSORES
#-----------------------------------------------------------------
	delimiter //
		drop procedure if exists copiarEquipos //
        create procedure copiarEquipos() 
            begin
				#Declaramos las variables necesarias
					declare nombre_backup, ciudad_backup	varchar( 20 );
                    declare conferencia_backup				varchar( 4 );
                    declare division_backup					varchar( 9 );
                    declare FIN								int			default FALSE;
                    
                #Declaramos el cursor
					declare cursorEquipos CURSOR FOR	
						select nombre, ciudad, conferencia, division from equipos;
				
                #Declaramos la condición de finalización de la lectura de equipos
					declare continue handler for NOT FOUND set FIN = TRUE;
				
                #Abrir el cursor
					open cursorEquipos;
				
                #Recorremos todos los equipos
					bucle: while( NOT FIN ) DO
						fetch cursorEquipos into
							nombre_backup, ciudad_backup, conferencia_backup, division_backup;
						insert into equipos_backup values 
							(nombre_backup, ciudad_backup, conferencia_backup, division_backup);
                    end while bucle;
				
                #Cerramos el cursor
					close cursorEquipos;
            end //
    delimiter ;


#call copiarEquipos(); 	select * from equipos_backup;
#select copiarEquipos();	select * from equipos_backup;
call copiarEquipos(); 	select * from equipos_backup;