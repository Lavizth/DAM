/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tablademultiplicar;

/**
 *
 * @author a14deividdd
 */
public class TablaDeMultiplicar {

    public static void main(String[] args) {
        Frame frame = new Frame("");
        frame.setVisible(true);
    }
    
}



