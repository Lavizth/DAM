/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablademultiplicar;

/**
 *
 * @author Lavizth
 */
public interface ConstructorPanel {
    abstract void iniciar();
    abstract void añadir();
}
